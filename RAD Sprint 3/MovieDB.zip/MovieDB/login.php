<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-16">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>RAD Movie Search</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">

  <!-- Color and font for all pages -->
  <link href="css/color.css" rel="stylesheet">

  <!-- Styles for the login pages -->
  <link href="css/loginPages.css" rel="stylesheet">

</head>

<body>


  <div class="d-flex" id="wrapper">
    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">RAD Movie Search</div>
      <div class="list-group list-group-flush">
        <a href="index.php" class="list-group-item list-group-item-action bg-light">Main page</a>
      </div>
    </div>


    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <button class="btn btn-primary" id="menu-toggle">Toggle Menu</button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">Home<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="searchgraph.php">Top 10 Movies<span class="sr-only"></span></a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="moviesSearch.php">Search Movies<span class="sr-only"></span></a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="login.php">Login<span class="sr-only"></span></a>
            </li>
          </ul>
        </div>
      </nav>
      <div>

      <o>
      <?php
            require "connect.php";
            if (!isset($_POST['submit'])) 
            { 

                ?>

                <!--Create form-->
                <h1>Newsletter</h1><br>
                <form action="<?php echo $_SERVER['PHP_SELF'];?>"method="post">

                <p>

                <!--Text Boxes-->
                <div>
                  <div class="left">
                    <label>Name:</label>
                  </div>
                  <div class="right">
                    <input type="text" name="name" id="txtboxSize"/>
                  </div>
                </div>

                <br>
                <br>
                <div>
                  <div class="left">
                    <label>Email:</label>
                  </div>
                  <div class="right">
                    <input type="text" name="email" id="txtboxSize"/>
                  </div>
                </div>
                <br>
                <br>

                <!--Check Boxes-->
                <input type="checkbox" name="send_email" value="on"> Send an email &nbsp;
                <input type="checkbox" name="show_notification" value="on"> Show notifications
                <br>
                <br>

                <!--Buttons-->
                <input type="submit" name="submit" value="Sign Up" id="btnSize"/>
                <input type="submit" name="submit" value="Unsubscribe" id="btnSize"/>
                <br>
                <br>

                <a href='loginAdmin.php'>Sign in as admin</a>

                </p>

                </form> 

            <?php  
            }
            //Start of php script
            else 
            {
              $name = $_POST['name'];
              $email = $_POST['email']; 
              $button = $_POST['submit'];
              $send_email = $_POST['send_email'];
              $show_notification = $_POST['show_notification'];
              
              //Full name can include any letters and must have a space in between
              $regex_name = "([a-zA-Z]*\s[a-zA-Z]*)";

              //Email must include @ and can end in .com, .com.au, .net or .org
              $regex_email = "([a-zA-Z]*\.?[0-9a-zA-Z]+[@][a-zA-Z]+[.](com\.au|com|net|org){1})";
  
              //Sign up button
              if ($button == "Sign Up")
              {
                //If email matches the regex
                if (preg_match($regex_email, $email)) 
                {
                  //And if name matches regex
                  if (preg_match($regex_name, $name)) 
                  {
                    //Check if email is already in database
                    $exists = mysqli_query($conn, "SELECT email FROM users WHERE email = '$email'");

                    //If email exists, display an error
                    if (mysqli_num_rows($exists) > 0)
                    {
                      echo "</br><o>The email: $email is already used.</o></br>
                      <o><a href='login.php'>Login</a></o>";
                    }

                    else
                    {
                      //If only email is checked
                      if ($send_email == "on" && $show_notification == null)
                      {
                        //Query to add the user to the database
                        $query = "INSERT INTO users (name, email, send_email, show_notification) VALUES('$name','$email', 1, 0)";

                        //Run the query
                        if (mysqli_query($conn, $query))
                        {
                          $name = stripslashes($name);
                          echo "</br><o>'$email' will now receive emails.</o></br>
                          <o><a href='login.php'>Login</a></o>";
                        }
                      }

                      //If only notification is checked
                      else if ($show_notification == "on" && $send_email == null)
                      {
                        //Query to add the user to the database
                        $query = "INSERT INTO users (name, email, send_email, show_notification) VALUES('$name','$email', 0, 1)";

                        //Run the query
                        if (mysqli_query($conn, $query))
                        {
                          $name = stripslashes($name);
                          echo "</br><o>'$email' will now receive notifications.</o></br>
                          <o><a href='login.php'>Login</a></o>";
                        } 
                      }

                      //Check if subscription is both
                      else if ($send_email == "on" && $show_notification == "on")
                      {
                        //Query to add the user to the database
                        $query = "INSERT INTO users (name, email, send_email, show_notification) VALUES('$name','$email', 1, 1)";

                        //Run the query
                        if (mysqli_query($conn, $query))
                        {
                          $name = stripslashes($name);
                          echo "</br><o>'$email' will now receive emails and notifications.</o></br>
                          <o><a href='login.php'>Login</a></o>";
                        } 
                      }
                      
                      //If neither send emails or show notifications were checked, display an error
                      else if (!($send_email == "on" && $show_notification == "on"))
                      {
                        echo "</br><o>Emails and/or notifications must be selected.</o></br>
                        <o><a href='login.php'>Login</a></o>";
                      }
                      
                      //Display any other errors
                      else 
                      {
                        echo "Error: " . mysqli_error($conn);
                      }

                    }

                  }

                  //The email is not in the database, display an error.
                  else
                  {
                    echo "</br><o>Invalid name.</o></br>
                    <o><a href='login.php'>Login</a></o>";
                  }

                }
                //Email doesnt match regex, display an error
                else
                {
                  echo "</br><o>Invalid address.</o></br>
                  <o><a href='login.php'>Login</a></o>";
                }

              }

              //Unsubscribe button
              else if ($button == "Unsubscribe")
              {
                  if (preg_match($regex_email, $email))
                  {
                      //Check if email is already in database
                      $exists = mysqli_query($conn, "SELECT email FROM users WHERE email = '$email'");

                      //If email exists in database
                      if (mysqli_num_rows($exists) > 0) 
                      {
                        
                        //Using PHPMailer to send emails
                        require_once ('PHPMailer/PHPMailerAutoload.php'); 
                        $mail = new PHPMailer();
                        $mail->isSMTP();
                        $mail->SMTPAuth = true;
                        $mail->SMTPSecure = 'tls';
                        $mail->Host = 'smtp.gmail.com';
                        $mail->Port = '587';
                        $mail->isHTML();
                        $mail->SMTPDebug = 0;

                        //Email address
                        $mail->Username = 'taferademail7890@gmail.com';

                        //Password for address
                        $mail->Password = 'RADTafe1!';

                        //Recipient of email
                        $mail->AddAddress('taferademail7890@gmail.com');

                        //Subject and body
                        $mail->Subject = 'Newsletter Cancellation';
                        $mail->Body = "The user $email is requesting to unsubscribe.";

                        //Sends the email succesfully.
                        if($mail->Send())
                        {
                          echo "</br><o>A cancellation email has been sent.</o></br>
                          <o><a href='login.php'>Login</a></o>";
                        }            

                        //If the email fails, display an error.
                        else
                        {
                          echo "Error: " . $mail->ErrorInfo;
                        }

                      }
                      //The email is not in the database, display an error.
                      else
                      {
                        echo "</br><o>The email is not registered on the website.</o></br>
                        <o><a href='login.php'>Login</a></o>";
                      } 

                  }
                  //Email doesnt match regex, display an error
                  else
                  {
                    echo "</br><o>Invalid address.</o></br>
                    <o><a href='login.php'>Login</a></o>";
                  }

              }

            }      
            ?>
      </div>
      </o>

      <!-- /#wrapper -->

      <!-- Bootstrap core JavaScript -->
      <script src="vendor/jquery/jquery.min.js"></script>
      <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

      <!-- Menu Toggle Script -->
      <script>
        $("#menu-toggle").click(function(e) {
          e.preventDefault();
          $("#wrapper").toggleClass("toggled");
        });
      </script>
</body>