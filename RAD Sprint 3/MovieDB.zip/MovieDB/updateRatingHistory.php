<?php
  
  require "connect.php";
  
  //Get top 10 rated movies from ratinghistory
  $sql = "SELECT title1, title2, title3, title4, title5, title6, title7, title8, title9, title10 FROM ratinghistory ORDER BY id DESC LIMIT 1";
  $result = mysqli_query($conn, $sql);
  $list = null;

  //Write top 10 movies to a string
  $row = mysqli_fetch_array($result);
  $list = $row["title1"];
  $list .= $row["title2"];
  $list .= $row["title3"];
  $list .= $row["title4"];
  $list .= $row["title5"];
  $list .= $row["title6"];
  $list .= $row["title7"];
  $list .= $row["title8"];
  $list .= $row["title9"];
  $list .= $row["title10"];
  

  //Get top 10 rated movies from movie table
  $sql = "SELECT * FROM movies ORDER BY score DESC LIMIT 10";
  $result = mysqli_query($conn, $sql);
  $newlist = null;
  $arr = null;
  $i = 0;
  
  //Write movie names and scores to the array
  while ($row = mysqli_fetch_array($result)) 
  {
    // Adds title to a second string to be compared to previous.
    $newlist .= $row["title"];
    $arr[$i][0] = addslashes($row["title"]);
    $arr[$i][1] = $row["score"];

    $i++;
  }

  //If new top 10 list has different movies, update the ratinghistory table
  if ($newlist != $list)
  {
    $sql = "INSERT INTO ratinghistory (title1, rank1,
                                        title2, rank2,
                                        title3, rank3,
                                        title4, rank4,
                                        title5, rank5,
                                        title6, rank6,
                                        title7, rank7,
                                        title8, rank8,
                                        title9, rank9,
                                        title10, rank10)
    VALUES ('". $arr[0][0] ."', ". $arr[0][1] .
        ", '". $arr[1][0] ."', ". $arr[1][1] .
        ", '". $arr[2][0] ."', ". $arr[2][1] .
        ", '". $arr[3][0] ."', ". $arr[3][1] .
        ", '". $arr[4][0] ."', ". $arr[4][1] .
        ", '". $arr[5][0] ."', ". $arr[5][1] .
        ", '". $arr[6][0] ."', ". $arr[6][1] .
        ", '". $arr[7][0] ."', ". $arr[7][1] .
        ", '". $arr[8][0] ."', ". $arr[8][1] .
        ", '". $arr[9][0] ."', ". $arr[9][1] .")";
    mysqli_query($conn, $sql);
  }
?>