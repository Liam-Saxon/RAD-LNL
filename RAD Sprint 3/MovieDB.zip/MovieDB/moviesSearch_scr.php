<!-- Color and font for all pages -->
<link href="css/color.css" rel="stylesheet">

<main class="col-lg-9">
    <article class="col-lg-12">
        <?php
        /**
         * Footer
         *
         * Main footer file for the theme.
         *
         * @category   Components
         * @package    WordPress
         * @subpackage Theme_Name_Here
         * @author     Your Name <yourname@example.com>
         * @license    https://www.gnu.org/licenses/gpl-3.0.txt GNU/GPLv3
         * @link       https://yoursite.com
         * @since      1.0.0
         */
        
        error_reporting(E_ALL);
        ini_set('display_errors', 1);

        /**
         * Connect to mySQL using connect.php 
         */
        require "connect.php";

        session_start();

        // Includes script for updating history table with top 10 rated movies.
        include "updateRatingHistory.php";

        // Checks if an ID has been specified to upvote.
        if (isset($_SESSION["upvote"]))
        {
            // Query for adding one to ID's score (upvoting).
            $id = $_SESSION['upvote'];
            $sql = "UPDATE movies SET score = score + 1 WHERE id = '$id'";
            mysqli_query($conn, $sql);

            // After query is completed the variable is cleared
            // to prevent a loop and the page is refreshed.
            unset($_SESSION["upvote"]);
            header("Refresh:0");
        }

        // Checks if an ID has been specified to downvote.
        else if (isset($_SESSION["downvote"]))
        {
            // Query for subtracting one from ID's score (downvoting).
            $id = $_SESSION['downvote'];
            $sql = "UPDATE movies SET score = score - 1 WHERE id = '$id'";
            mysqli_query($conn, $sql);

            // After query is completed the variable is cleared
            // to prevent a loop and the page is refreshed.
            unset($_SESSION["downvote"]);
            header("Refresh:0");
        }

        // If there is no pending vote, load the movies.
        else
        {
            if (!isset($_POST['submit'])) {
                ?>
                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
                    <div class="form-group">
                        <label for="searchT">Title:</label>
                        <input type="text" class="form-control" id="searchT" name="searchT">
                    </div>
                    <div class="form-group">
                        <label for="searchR">Rating:</label>
                        <input type="text" class="form-control" id="searchR" name="searchR">
                    </div>
                    <div class="form-group">
                        <label for="searchY">Year:</label>
                        <input type="text" class="form-control" id="searchY" name="searchY">
                    </div>
                    <div class="form-group">
                        <label for="searchG">Genre:</label>
                        <input type="text" class="form-control" id="searchG" name="searchG">
                    </div>

                    <button type="submit" name="submit" class="btn btn-default">Submit</button>
                </form>
                <br>
                <?php
            } else {

                //initialise empty string for error messages
                $error_msg = "";
                //firstname
                if ($_POST['searchT']) {
                    //assign the filled value to the field
                    $searchT = $_POST['searchT'];

                    $searchT = filter_var($searchT, FILTER_SANITIZE_STRING);
                }
                //lastname
                if ($_POST['searchR']) {
                    //assign the filled value to the field
                    $searchR = $_POST['searchR'];

                    $searchR = filter_var($searchR, FILTER_SANITIZE_STRING);
                }
                //phone
                if ($_POST['searchY']) {
                    //assign the filled value to the field
                    $searchY = $_POST['searchY'];

                    $searchY = filter_var($searchY, FILTER_SANITIZE_STRING);
                }
                if ($_POST['searchG']) {
                    //assign the filled value to the field
                    $searchG = $_POST['searchG'];

                    $searchG  = filter_var($searchG, FILTER_SANITIZE_STRING);
                }
            }


            
            @$sql = "SELECT *
            FROM movies
            WHERE  title LIKE '%" . $searchT . "%' AND rating LIKE '%" . $searchR . "%' AND year LIKE '%" . $searchY . "%' AND genre LIKE '%" . $searchG . "%'
            ";

            @$sql2 = "UPDATE movies 
            SET searchcount = searchcount + 1
            WHERE title = '" . $searchT . "' ";

            $result = $conn->query($sql);
            $result2 = $conn->query($sql2);

            if ($result->num_rows > 0 && $result2) {

                // If user clicks the upvote button a session variable
                // is set indicating the ID to upvote; the page is refreshed.
                if(isset($_POST['upvote']))
                {
                    $_SESSION["upvote"] = $_POST['id'];
                    //header("Refresh:0");
                }

                // If user clicks the downvote button a session variable
                // is set indicating the ID to downvote; the page is refreshed.
                if(isset($_POST['downvote']))
                {
                    $_SESSION["downvote"] = $_POST['id'];
                    //header("Refresh:0");
                }

                echo '<table class="table-light table-hover" id="outTable">';
                echo "<tr><th>Movie ID</th><th>Title</th><th>Studio</th><th>Status</th><th>Sound</th><th>Version</th><th>Recommended retail price</th><th>Rating</th><th>Year</th><th>Genre</th><th>Aspect</th><th>User Rating</th><th>Vote</th></tr>";
                while ($row = $result->fetch_assoc()) {
                    echo "
                    <tr>
                    <td onclick=popfields(" . $row['id'] . ")>" . $row["id"] . "</td>
                    <td>" . $row["title"] . "</td>
                    <td>" . $row["studio"] . "</td>
                    <td>" . $row["status"] . "</td>
                    <td>" . $row["sound"] . "</td>
                    <td>" . $row["versions"] . "</td>
                    <td>" . $row["recretprice"] . "</td>
                    <td>" . $row["rating"] . "</td>
                    <td>" . $row["year"] . "</td>
                    <td>" . $row["genre"] . "</td>
                    <td>" . $row["aspect"] . "</td>
                    <td>" . $row["score"] . "</td>


                    <td>
                    <form  method='post'>
                    <input type='hidden' name='id' value='" . $row['id'] . "'/>
                    <input class='votebtn' type='submit' name='upvote'  value='▲'> </form>

                    <form  method='post'>
                    <input type='hidden' name='id' value='" . $row['id'] . "' />
                    <input class='votebtn' type='submit' name='downvote'  value='▼'> </form>
                    </td>
                    
                    
                    </tr>";
                }
            } else {
                echo "Nothing found";
            }
        }
        //Close sqli connection
        mysqli_close($conn);
        ?>
    </article>
</main>