<?php

/**
 * Footer
 *
 * Main footer file for the theme.
 *
 * @category   Components
 * @package    WordPress
 * @subpackage Theme_Name_Here
 * @author     Your Name <yourname@example.com>
 * @license    https://www.gnu.org/licenses/gpl-3.0.txt GNU/GPLv3
 * @link       https://yoursite.com
 * @since      1.0.0
 */

   require "connect.php";

   $sql = "SELECT * FROM ratinghistory";
   $result = $conn->query($sql);
   $numrows = $result->num_rows;
?>

<form method="post"> 
   <label for="graphid">Select history to show:</label>
   <select name="graphid" id="graphid">
      <?php
         for ($count = 1; $count < $numrows + 1; $count++) {
            echo "<option value=$count>$count</option>";
         }
      ?>
   </select>
   <input type="submit" name="button1" class="button" value="Show"/>
</form>

<?php
   if(isset($_POST['button1'])) {
      $id = $_POST['graphid'];
      echo "Showing history graph <b>$id</b>";

      $sql = "SELECT * FROM ratinghistory
      WHERE id=$id";
      $result = $conn->query($sql);

      if ($result->num_rows) {
         $row = $result->fetch_assoc();

         $data[0][0] = $row['title1'];
         $data[1][0] = $row['title2'];
         $data[2][0] = $row['title3'];
         $data[3][0] = $row['title4'];
         $data[4][0] = $row['title5'];
         $data[5][0] = $row['title6'];
         $data[6][0] = $row['title7'];
         $data[7][0] = $row['title8'];
         $data[8][0] = $row['title9'];
         $data[9][0] = $row['title10'];

         $data[0][1] = $row['rank1'];
         $data[1][1] = $row['rank2'];
         $data[2][1] = $row['rank3'];
         $data[3][1] = $row['rank4'];
         $data[4][1] = $row['rank5'];
         $data[5][1] = $row['rank6'];
         $data[6][1] = $row['rank7'];
         $data[7][1] = $row['rank8'];
         $data[8][1] = $row['rank9'];
         $data[9][1] = $row['rank10'];
      }

      // Image dimensions
      $imageWidth = 2100;
      $imageHeight = 700;

      // Grid dimensions and placement within image
      $gridTop = 40;
      $gridLeft = 25;
      $gridBottom = 600;
      $gridRight = 2100;
      $gridHeight = $gridBottom - $gridTop;
      $gridWidth = $gridRight - $gridLeft;

      // Bar and line width
      $lineWidth = 1;
      $barWidth = 20;

      // Font settings
      $font = 'OpenSans-Regular.ttf';
      $fontSize = 8;

      // Margin between label and axis
      $labelMargin = 10;

      // Max value on y-axis
      $yMaxValue = 25;

      // Distance between grid lines on y-axis
      $yLabelSpan = 5;

      // Init image
      $chart = imagecreate($imageWidth, $imageHeight);

      // Setup colors
      $backgroundColor = imagecolorallocate($chart, 255, 255, 255);
      $axisColor = imagecolorallocate($chart, 85, 85, 85);
      $labelColor = $axisColor;
      $gridColor = imagecolorallocate($chart, 212, 212, 212);
      $barColor = imagecolorallocate($chart, 47, 133, 217);

      imagefill($chart, 0, 0, $backgroundColor);

      imagesetthickness($chart, $lineWidth);

      /*
 * Print grid lines bottom up
 */

      for ($i = 0; $i <= $yMaxValue; $i += $yLabelSpan) {
         $y = $gridBottom - $i * $gridHeight / $yMaxValue;

         // draw the line
         imageline($chart, $gridLeft, $y, $gridRight, $y, $gridColor);

         // draw right aligned label
         $labelBox = imagettfbbox($fontSize, 0, $font, strval($i));
         $labelWidth = $labelBox[4] - $labelBox[0];

         $labelX = $gridLeft - $labelWidth - $labelMargin;
         $labelY = $y + $fontSize / 2;

         imagettftext($chart, $fontSize, 0, $labelX, $labelY, $labelColor, $font, strval($i));
      }

      /*
 * Draw x- and y-axis
 */

      imageline($chart, $gridLeft, $gridTop, $gridLeft, $gridBottom, $axisColor);
      imageline($chart, $gridLeft, $gridBottom, $gridRight, $gridBottom, $axisColor);

      /*
 * Draw the bars with labels
 */

      $barSpacing = 200;
      $itemX = $gridLeft + $barSpacing / 2;

      foreach ($data as $arr) {
         // Draw the bar
         $x1 = $itemX - $barWidth / 2;
         $y1 = $gridBottom - $arr[1] / $yMaxValue * $gridHeight;
         $x2 = $itemX + $barWidth / 2;
         $y2 = $gridBottom - 1;

         imagefilledrectangle($chart, $x1, $y1, $x2, $y2, $barColor);

         // Draw the label
         $labelBox = imagettfbbox($fontSize, 0, $font, $arr[0]);
         $labelWidth = $labelBox[4] - $labelBox[0];

         $labelX = $itemX - $labelWidth / 2;
         $labelY = $gridBottom + $labelMargin + $fontSize;

         imagettftext($chart, $fontSize, 0, $labelX, $labelY, $labelColor, $font, $arr[0]);

         $itemX += $barSpacing;
      }

      /*
 * Output image to browser
 */

      imagepng($chart, 'chart.png');

      unset($_SESSION['button1']);
   } 
?>